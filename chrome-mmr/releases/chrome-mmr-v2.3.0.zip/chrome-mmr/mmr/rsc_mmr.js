let currentTracker = null;
let rsc_name = '';

let tracker_link   = null;
let tracker_status = null;
let old_link       = null;
let fixed          = false;

let current_season = 25;

// respect the "on/off" setting
let ACTIVE = true;

(async () => {
	// Sends a message to the service worker and receives a tip in response
	//const { tip } = await chrome.runtime.sendMessage({ greeting: 'tip' });
	currentTracker = window.location.href;

	const popover = createDomElement(
		`<div id='rsc-mmr-popover' style="display:flex;position:fixed;height:55px;justify-content:space-evenly;align-items:center;top:0;right:0;background-color:#f3fa28;border:2px solid #fa4128;padding-left:5px;padding-right:5px;z-index:10000;color:#000;">
			<span id="rsc-mmr-message" style="display:inline-block;font-weight:bold;">RSC MMR LOADED</span>
			<img src="https://devleague.rscstream.com/icons/rsc-mmr-128.png" style="height:32px;">
		</div>`
	);
	document.body.append(popover);

	chrome.storage.local.get('rsc_name', (result) => {
		rsc_name = result.rsc_name;
	});

	chrome.storage.local.get('ACTIVE', (result) => {
		ACTIVE = result.ACTIVE;
		if ( ! ACTIVE ) {
			document.getElementById('rsc-mmr-message').innerText = 'RSC MMR Disabled';
		}
	});

	chrome.storage.local.get('tracker_process', (result) => {
		tracker_link   = result.tracker_process.link;
		tracker_status = result.tracker_process.status;
		old_link       = result.tracker_process.old_link;
		fixed          = result.tracker_process.fixed;
	});

	setTimeout(function() {
		if ( ACTIVE ) {
			fetchMmr();
		}
	}, 1000);
})();

setInterval(checkChanges, 5000);

function checkChanges() {
	if ( ! ACTIVE ) { return true; }
	if ( window.location.href !== currentTracker ) {
		console.log('Our tracker has changed!');
		document.getElementById('rsc-mmr-message').innerText = 'Loading tracker...';
		currentTracker = window.location.href;
		
		// fetch this mmr
		fetchMmr();
	}
}

function fetchMmr(past_season) {
	let season = 25;
	if ( past_season ) {
		season = past_season;
	}
	let el = document.getElementById('rsc-mmr-message');
	el.innerText = 'RSC MMR Loading...';

	let trackerLink = window.location.href;
	let checkString = 'rocketleague.tracker.network/rocket-league/profile';
	let trackerData = {
		tracker_link: { link: window.location.href },
		threes_rating: null,
		threes_games_played: null,
		threes_season_peak: null,
		twos_rating: null,
		twos_games_played: null,
		twos_season_peak: null,
		ones_rating: null,
		ones_games_played: null,
		ones_season_peak: null,
		notes: '',
		date_pulled: new Date(),
		psyonix_season: null,
		platform: null,
		user_id: null,
		pulled_by: rsc_name,
		status: null,
	};
	if ( tracker_link == window.location.href ) {
		trackerData.status = tracker_status;
		// we fixed the URL before coming here, so send the original link
		// back to the API
		if ( fixed ) {
			console.log('We fixed a link!');
			trackerData.tracker_link.link = old_link;
		}
	}

	if ( trackerLink.includes(checkString) ) {
		let components = trackerLink.split('/');
		let platform = components[5];
		let user_id = components[6];
		if ( components[ components.length - 1] != 'overview' && components[ components.length - 1 ] != user_id ) {
			console.log('skipping non-overview pages');
			return false;
		}
		fetch(`https://api.tracker.gg/api/v2/rocket-league/standard/profile/${platform}/${user_id}/segments/playlist?season=${season}`)
			.then(response => {
				if ( ! response.ok ) {
					throw new Error('404 Error');
				} else {
					return response.json();
				}
			})
			.then(data => {
				el.innerText = 'Storing!';
				console.log(data.data);
				let playlists = data.data;

				// we'll sometimes get an empty array from the API
				// It's an error/bad tracker if the season is the current one
				// but not an error if it's an older season and we're doing a 
				// deeper dive
				if ( ! playlists.length && season === current_season ) {
					throw new Error('Empty data');
				} else if ( ! playlists.length && season !== current_season ) {
					el.innerText = 'New Player Imported!';
					console.log(`No data for Season ${season}`);
					return false;
				}

				for ( let i = 0; i < playlists.length; ++i ) {
					let playlist = playlists[i];
					if ( playlist.attributes.playlistId == 13 ) {
						trackerData.threes_rating = playlist.stats.rating.value;
						trackerData.threes_games_played = playlist.stats.matchesPlayed.value;
						trackerData.threes_season_peak = playlist.stats.peakRating.value;
					} else if ( playlist.attributes.playlistId == 11 ) {
						trackerData.twos_rating = playlist.stats.rating.value;
						trackerData.twos_games_played = playlist.stats.matchesPlayed.value;
						trackerData.twos_season_peak = playlist.stats.peakRating.value;
					} else if ( playlist.attributes.playlistId == 10 ) {
						trackerData.ones_rating = playlist.stats.rating.value;
						trackerData.ones_games_played = playlist.stats.matchesPlayed.value;
						trackerData.ones_season_peak = playlist.stats.peakRating.value;
					}

					trackerData.psyonix_season = playlist.attributes.season;
					trackerData.platform = platform;
					trackerData.user_id = user_id;
				}

				fetch('https://devleague.rscstream.com/save_mmr', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(trackerData)
				}).then(response => {
					if ( response.ok ) {
						return response.json();
					} else {
						console.error("Post failed!", response);
					}
				}).then(data => {
					if ( data.success ) {	
						console.log('save successful');
						el.innerText = 'MMR Saved!';

						// if it's our first pull, try to get two seasons
						if ( trackerData.status == 'NEW' ) {
							let old_season = season - 1;
							console.log(`Trying to grab season ${old_season}`);
							if ( old_season >= (current_season - 2) ) {
								el.innerText = `Fetching Season ${old_season}`;
								setTimeout(() => { fetchMmr(old_season) }, 1000);
								return true;
							}
						}

					} else if ( data.recent )  {
						console.log('save not needed');
						el.innerText = 'Tracker Recently Pulled - Skipping';

					} else if ( data.not_found )  {
						console.log('save not needed');
						el.innerText = 'Not a player';

					} else {
						console.log('Unknown Error');
						el.innerText = 'Error!';
					}
				}).catch(error => {
					el.innerText = 'Error!';
					console.log('Error:', error);
				});
			}).catch(error => {
				el.innerText = 'Error!';

				fetch('https://devleague.rscstream.com/bad_tracker', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify({'pulled_by': rsc_name, 'tracker_link': old_link, 'current_page': window.location.href })
				}).then(response => response.json())
				.then(json => {
					el.innerText = 'Error - logged!';
				});
			});
	} else {
		// we're not on a profile page, but if we got here from the API endpoint
		// that provided us with this URL, log this tracker as "bad"
		if ( currentTracker === tracker_link ) {
			fetch('https://devleague.rscstream.com/bad_tracker', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({'pulled_by': rsc_name, 'tracker_link': window.location.href })
			}).then(response => response.json())
			.then(json => {
				el.innerText = 'Error - logged!';
			});
		} else {
			el.innerText = 'Not a Profile';
		}
	}
}

function createDomElement(html) {
	const dom = new DOMParser().parseFromString(html, 'text/html');
	return dom.body.firstElementChild;
}

console.log('RSC MMR Checker Loaded!');