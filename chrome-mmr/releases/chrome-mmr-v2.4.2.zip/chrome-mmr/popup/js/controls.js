const CURRENT_VERSION = '2.4.2';
let ACTIVE = true;
let RSC_NAME = false;
let PANEL = 'setup';

function toggle_on_off(ev) {
	chrome.storage.local.set({ 'ACTIVE': ev.currentTarget.checked });
	if ( ev.currentTarget.checked ) {
		turnOnButton();
	} else {
		turnOffButton();
	}
}

function turnOnButton() {
	const process_button = document.getElementById('process');
	const disabled_p = document.getElementById('disabled');
	if ( process_button ) {
		process_button.style.display = 'inline-block';
		disabled_p.style.display = 'none';
	}
}

function turnOffButton() {
	const process_button = document.getElementById('process');
	const disabled_p = document.getElementById('disabled');
	if ( process_button ) {
		process_button.style.display = 'none';
		disabled_p.style.display = 'block';
	}
}

document.addEventListener('DOMContentLoaded', () => {
	let rsc_name = null;

	const on_off = document.getElementById('on_off');
	if ( on_off ) {
		on_off.addEventListener('change', toggle_on_off);
		chrome.storage.local.get('ACTIVE', (result) => {
			if ( 'ACTIVE' in result ) {
				ACTIVE = result.ACTIVE;
			} else {
				// start to active if we've never run this before
				ACTIVE = true;
			}
			
			on_off.checked = ACTIVE;
			if ( ACTIVE ) {
				turnOnButton();
			} else {
				turnOffButton();
			}
		});
	}

	const saveButton = document.getElementById('save_name');
	if ( saveButton ) {
		saveButton.addEventListener('click', (ev) => {
			let nameEl = document.getElementById('name');
			let name = '';
			if ( nameEl ) {
				name = nameEl.value;
			}
			if ( name && name.trim() !== '' ) {
				console.log('saving name', name);
				chrome.storage.local.set({'rsc_name': name });
				document.getElementById('setup').style.display = 'none';
				document.getElementById('controls').style.display = 'block';
				PANEL = 'controls';
			} else {
				name.focus();
			}
		});
	}

	// we're still going to fetch the real counts, but load the panel with what we have first
	chrome.storage.local.get('tracker_counts', (result) => {
		if ( result && 'tracker_counts' in result && 'new' in result.tracker_counts ) {
			document.getElementById('new_trackers').innerText = result.tracker_counts.new;
			document.getElementById('stale_trackers').innerText = result.tracker_counts.stale;
		}
	});

	chrome.storage.local.get('rsc_name', (result) => {
		rsc_name = result.rsc_name;
		if ( rsc_name && rsc_name.trim() !== '' ) {
			RSC_NAME = rsc_name;
			console.log('logged in as ' + rsc_name);
			PANEL = 'controls';
			document.getElementById('setup').style.display = 'none';
			document.getElementById('controls').style.display = 'block';

			// grab our current stats
			fetch('http://24.176.157.36:4443/api/v1/tracker-links/links_stats/?format=json')
				.then(response => response.json())
				.then(data => {
					document.getElementById('new_trackers').innerText = data.new;
					document.getElementById('stale_trackers').innerText = data.stale;
					chrome.storage.local.set({'tracker_counts': { 'new': data.new, 'stale': data.stale }});
				}).catch(e => {
					console.log('An error occurred grabbing the link stats', e);
				});

			fetch(`https://devleague.rscstream.com/tracker/${rsc_name}`)
				.then(response => response.json())
				.then(data => document.getElementById('your_pulls').innerText = data.total)
				.catch(e => {
					document.getElementById('your_pulls').innerText = 'e!';
					console.log('An error occurred grabbing your stats', e);
				});
		}
	});

	let links = document.getElementsByTagName('a');
	for ( let i = 0; i < links.length; ++i ) {
		if ( links[i].classList.contains('button') ) {
			continue;
		}
		if ( links[i].classList.contains('settings') ) {
			continue;
		}
		links[i].addEventListener('click', (ev) => {
			chrome.tabs.create({ url: ev.currentTarget.getAttribute('href') }) ;
		});
	}
	document.getElementById('settings-light').addEventListener('click', showSettings);
	document.getElementById('settings-dark').addEventListener('click', showSettings);
	document.getElementById('process').addEventListener('click', processTracker);
});

function showSettings(ev) {
	if ( PANEL === 'controls' ) {
		PANEL = 'setup';
		document.getElementById('setup').style.display = 'block';
		document.getElementById('controls').style.display = 'none';
		if ( RSC_NAME ) {
			document.getElementById('name').value = RSC_NAME;
		}
		document.getElementById('name').focus();
	} else {
		PANEL = 'controls';
		document.getElementById('setup').style.display = 'none';
		document.getElementById('controls').style.display = 'block';
	}
}

function processTracker(ev) {
	let el = document.getElementById('your_pulls');
	let count = parseInt(el.innerText) + 1;
	el.innerText = count;
	let button = ev.currentTarget;
	let url = 'https://devleague.rscstream.com/get_tracker?delete=true';
	fetch(url)
		.then(response => response.json())
		.then(data => {

			if ( data.version && data.version !== CURRENT_VERSION ) {
				document.getElementById('process').disabled = true;
				document.getElementById('process').innerText = 'Version Mis-Match - Update';
				document.getElementById('process').removeEventListener('click', processTracker);
			} else { 

				let tracker = data.tracker;
				if ( tracker ) {
					chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
						let activeTab = tabs[0];
						let url = activeTab.url;

						let fixed = false;			
						let tracker_link = tracker.link;
						let old_link = tracker_link;
						// a lot of our links are stored very poorly. fix them if possible
						if ( tracker_link.includes('tracker.network/profile') ) {
							tracker_link = tracker_link.replace('tracker.network/profile', 'tracker.network/rocket-league/profile');
							tracker_link = tracker_link.replace('profile/ps/', 'profile/psn/');
							tracker_link = tracker_link.replace('profile/xbox/', 'profile/xbl/');

							fixed = true;
						}

						let el = document.getElementById(tracker.status.toLowerCase() + '_trackers');
						if ( el ) {
							let count = parseInt(el.innerText);
							el.innerText = count - 1;
						}

						if ( url.includes('tracker.network') ) {
							chrome.storage.local.set({'tracker_process': { link: tracker_link, status: tracker.status, fixed: fixed, old_link: old_link } });
							chrome.tabs.update(activeTab.id, { url: tracker_link });
						} else {
							chrome.storage.local.set({'tracker_process': { link: tracker_link, status: tracker.status, fixed: fixed, old_link: old_link } });
							chrome.tabs.create({ url: tracker_link });
						}

						//window.close();
					});
				} else {
					document.getElementById('process').disabled = true;
					document.getElementById('process').innerText = 'None Available for you';
				}
			}
		}).catch(e => {
			console.log('Unknown error:', e);
		});
}