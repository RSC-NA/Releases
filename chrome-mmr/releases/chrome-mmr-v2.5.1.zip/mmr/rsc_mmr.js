let currentTracker = null;
let rsc_name = '';

let tracker_link   = null;
let tracker_status = null;
let old_link       = null;
let fixed          = false;
let from_api       = false; // if we're here because the API gave it
                            // we will force this through.

const current_season = 25;

// respect the "on/off" setting
let ACTIVE = true;
// tracker for "FULL_MODE"
let FULL_PULLS = false;
// color holder
const full_pulls_color = '#a10000';

(() => {
	// Sends a message to the service worker and receives a tip in response
	//const { tip } = await chrome.runtime.sendMessage({ greeting: 'tip' });
	currentTracker = window.location.href;

	const popover = createDomElement(
		`<div id='rsc-mmr-popover' style="display:flex;position:fixed;height:55px;justify-content:space-evenly;align-items:center;top:0;right:0;background-color:#f3fa28;border:2px solid #fa4128;padding-left:5px;padding-right:5px;z-index:10000;color:#000;">
			<span id="rsc-mmr-message" style="display:inline-block;font-weight:bold;">RSC MMR LOADED</span>
			<img src="https://devleague.rscstream.com/icons/rsc-mmr-128.png" style="height:32px;">
		</div>`
	);
	document.body.append(popover);

	chrome.storage.local.get('rsc_name', (result) => {
		rsc_name = result.rsc_name;
	});

	chrome.storage.local.get('ACTIVE', (result) => {
		ACTIVE = result.ACTIVE;
		if ( ! ACTIVE ) {
			document.getElementById('rsc-mmr-message').innerText = 'RSC MMR Disabled';
		}
	});

	chrome.storage.local.get('FULL_PULLS', (result) => {
		if ( 'FULL_PULLS' in result ) {
			FULL_PULLS = result.FULL_PULLS;
		}

		if ( FULL_PULLS ) {
			popover.style.backgroundColor = full_pulls_color;
			popover.style.color = 'yellow';
			popover.style.borderColor = 'gold';
		}
		console.log('FULL_PULLS -> ', FULL_PULLS);
	});

	chrome.storage.local.get('tracker_process', (result) => {
		tracker_link   = result.tracker_process.link;
		tracker_status = result.tracker_process.status;
		old_link       = result.tracker_process.old_link;
		fixed          = result.tracker_process.fixed;
		from_api       = result.tracker_process.from_api;
	});

	setTimeout(function() {
		if ( ACTIVE ) {
			fetchMmr();
		}
	}, 1000);
})();

setInterval(checkChanges, 5000);

function checkChanges() {
	if ( ! ACTIVE ) { return true; }
	if ( ! window.location.href.includes(currentTracker) ) {
		console.log('Our tracker has changed!');
		document.getElementById('rsc-mmr-message').innerText = 'Loading tracker...';
		currentTracker = window.location.href;
		
		// fetch this mmr
		fetchMmr();
	}
}

const RL_SEASONS = {
	'25': { start: '2023-06-07', end: '2023-09-06' },
	'24': { start: '2023-03-08', end: '2023-06-06' },
	'23': { start: '2022-12-07', end: '2023-03-07' },
	'22': { start: '2022-09-07', end: '2022-12-06' },
	'21': { start: '2022-06-15', end: '2022-09-06' },
	'20': { start: '2022-03-09', end: '2022-06-14' },
	'19': { start: '2021-11-17', end: '2022-03-08' },
	'18': { start: '2021-08-11', end: '2021-11-16' },
	'17': { start: '2021-04-07', end: '2021-08-10' },
	'16': { start: '2020-12-09', end: '2021-04-06' },
	'15': { start: '2020-09-23', end: '2020-12-08' },
};

function getSeasonByDate(dateStr) {
	const fetch_time = new Date(dateStr).getTime();
	for ( const season in RL_SEASONS ) {
		const start_time = new Date(RL_SEASONS[ season ].start).getTime();
		const end_time = new Date(RL_SEASONS[ season ].end).getTime();

		if ( fetch_time >= start_time && fetch_time <= end_time ) {
			return parseInt(season);
		}
	}

	return false;
}

function sendHistorical(trackers) {
	const el = document.getElementById('rsc-mmr-message');
	if ( trackers.length ) {
		const trackerData = trackers.pop();

		el.innerText = `Sending S${trackerData.psyonix_season}`;
		fetch('https://devleague.rscstream.com/save_mmr', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(trackerData)
		}).then(response => response.json())
		.then(_json => { 
			console.log(`Remaining trackers: ${trackers.length}`);
			el.innerText = `S${trackerData.psyonix_season} Saved!`;
			if ( trackers.length ) {
				setTimeout(() => { sendHistorical(trackers) }, 500);
			} else {
				el.innerText = `Finished! Go again?`;
			}
		});
	}
}

function fetchHistorical(RTN_player_id, trackerData) {
	console.log(RTN_player_id, trackerData);
	const ranked_playlists = [ 13, 11, 10, '13', '11', '10' ];

	const player_season_data = {};
	const season_peaks  = {};
	const season_ends   = {};
	let oldest_season = current_season; // assume we're starting from now and work backwards

	for ( const season in RL_SEASONS ) {
		// clone our trackerData object so that we can modify it for each season
		player_season_data[ `S${season}` ] = { ...trackerData };

		season_peaks[ `S${season}` ] = { '3s': 0, '2s': 0, '1s': 0 };
		season_ends[ `S${season}` ] = { '3s': 0, '2s': 0, '1s': 0 };
	}

	const plmap = { 13: '3s', 11: '2s', 10: '1s' };

	const trackers = [];

	fetch(`https://api.tracker.gg/api/v1/rocket-league/player-history/mmr/${RTN_player_id}`)
		.then(response => response.json())
		.then(json => {
			const playlists = json.data;
			for ( const playlist_id in playlists ) {
				if ( ! ranked_playlists.includes(playlist_id) ) {
					continue;
				}
				for ( let i = 0; i < playlists[ playlist_id ].length; ++i ) {
					const pull = playlists[ playlist_id ][i];
					const season = getSeasonByDate(pull.collectDate);
					if ( season < oldest_season ) {
						oldest_season = season;
					}

					const rating = pull.rating;
					// store our highest value for each season
					if ( rating > season_peaks[`S${season}`][ plmap[playlist_id] ]) {
						season_peaks[`S${season}`][ plmap[playlist_id] ] = rating; 
					}
					season_ends[`S${season}`][ plmap[playlist_id] ] = rating;
				}
			} // finish looping through all playlist data

			for ( const s in player_season_data ) {
				const s_int = parseInt(s.replace('S', ''));
				const tracker = player_season_data[s];
				const peaks = season_peaks[s];
				const ranks = season_ends[s];

				if ( s_int < oldest_season ) {
					console.log(`Skipping older season ${s_int} < ${oldest_season}`);
					continue;
				}

				if ( ! ( peaks['3s'] || peaks['2s'] || peaks['1s'] || ranks['3s'] || ranks['2s'] || ranks['1s'] ) ) {
					console.log(`Skipping empty data season ${s}`);
					continue;
				}

				tracker.threes_rating = ranks['3s'];
				tracker.threes_season_peak = peaks['3s'];
				tracker.twos_rating = ranks['2s'];
				tracker.twos_season_peak = peaks['2s'];
				tracker.ones_rating = ranks['1s'];
				tracker.ones_season_peak = peaks['1s'];
				tracker.psyonix_season = s_int;

				trackers.push(tracker);
			}

			console.log(trackers);

			console.log('Sending historical data to server.');
			setTimeout(() => { sendHistorical(trackers); }, 500);
	});
}

function fetchMmr(past_season, rtn_p_id, fallback_tracker_data) {
	console.log('fetchMmr(' + past_season + ')');
	console.log(tracker_link, window.location.href, old_link);
	console.log('fixed?', fixed);
	const el = document.getElementById('rsc-mmr-message');
	el.innerText = 'RSC MMR Loading...';

	let season = current_season;
	if ( past_season ) {
		season = past_season;
	}

	const trackerLink = window.location.href;
	const checkString = 'rocketleague.tracker.network/rocket-league/profile';
	const trackerData = {
		from_api: from_api,
		tracker_link: { link: window.location.href },
		threes_rating: null,
		threes_games_played: null,
		threes_season_peak: null,
		twos_rating: null,
		twos_games_played: null,
		twos_season_peak: null,
		ones_rating: null,
		ones_games_played: null,
		ones_season_peak: null,
		notes: '',
		date_pulled: new Date(),
		psyonix_season: null,
		platform: null,
		user_id: null,
		pulled_by: rsc_name,
		status: null,
	};
	if ( tracker_link == window.location.href ) {
		trackerData.status = tracker_status;
		// we fixed the URL before coming here, so send the original link
		// back to the API
		if ( fixed ) {
			console.log('We fixed a link!');
			trackerData.tracker_link.link = old_link;
		}
	} else if ( tracker_link !== null && tracker_link !== window.location.href ) {
		trackerData.tracker_link.link = tracker_link;
		if ( fixed ) {
			console.log('broken, but fixed!');
			trackerData.tracker_link.link = old_link;
		}
	}

	if ( trackerLink.includes(checkString) ) {
		const components = trackerLink.split('/');
		const platform = components[5];
		const user_id = components[6];
		let RTN_player_id = null;
		if ( components[ components.length - 1] != 'overview' && components[ components.length - 1 ] != user_id ) {
			console.log('skipping non-overview pages');
			return false;
		}
		let past_season_path  = '';
		let past_season_param = '';
		if ( past_season ) {
			past_season_path  = `/segments/playlist`;
			past_season_param = `season=${past_season}`;
		}

		const api_path = `${platform}/${user_id}${past_season_path}?${past_season_param}`;

		fetch(`https://api.tracker.gg/api/v2/rocket-league/standard/profile/${api_path}`, {
			"headers": {
				"accept": "application/json, text/plain, */*",
				"sec-ch-ua": "\"Not.A/Brand\";v=\"99\", \"Chromium\";v=\"115\", \"Google Chrome\";v=\"114\"",
				"sec-ch-ua-mobile": "?0",
				"sec-ch-ua-platform": "\"Windows\""
			},
			"referrer": "https://rocketleague.tracker.network/",
			"referrerPolicy": "strict-origin-when-cross-origin",
			"body": null,
			"method": "GET",
			"mode": "cors",
			"credentials": "include"
			})
			.then(response => {
				if ( ! response.ok ) {
					throw new Error('404 Error');
				} else {
					return response.json();
				}
			})
			.then(data => {
				el.innerText = 'Storing!';
				console.log(data.data);
				RTN_player_id = data.data.metadata?.playerId ?? null;
				let playlists; 
				
				if ( past_season !== undefined && FULL_PULLS ) {
					playlists = data?.data ?? [];

					if ( playlists.length === 0 && rtn_p_id && fallback_tracker_data ) {
						el.innerText = 'Falling Back to Year';
						return setTimeout(() => { 
							fetchHistorical(rtn_p_id, fallback_tracker_data);
						}, 200);
					} else if ( playlists.length === 0 ) {
						el.innerText = 'Something Went Wonky';
						return false;
					}
				} else {
					playlists = data.data?.segments ?? [];
				}

				// we'll sometimes get an empty array from the API
				// It's an error/bad tracker if the season is the current one
				// but not an error if it's an older season and we're doing a 
				// deeper dive

				for ( let i = 0; i < playlists.length; ++i ) {
					const playlist = playlists[i];

					// skip any non-playlist segments
					if ( playlist.type !== 'playlist' ) {
						continue;
					}

					if ( playlist.attributes.playlistId == 13 ) {
						trackerData.threes_rating = playlist.stats?.rating?.value ?? 0;
						trackerData.threes_games_played = playlist.stats?.matchesPlayed?.value ?? 0;
						trackerData.threes_season_peak = playlist.stats?.peakRating?.value ?? 0;
					} else if ( playlist.attributes.playlistId == 11 ) {
						trackerData.twos_rating = playlist.stats?.rating?.value ?? 0;
						trackerData.twos_games_played = playlist.stats?.matchesPlayed?.value ?? 0;
						trackerData.twos_season_peak = playlist.stats?.peakRating?.value ?? 0;
					} else if ( playlist.attributes.playlistId == 10 ) {
						trackerData.ones_rating = playlist.stats?.rating?.value ?? 0;
						trackerData.ones_games_played = playlist?.stats?.matchesPlayed?.value ?? 0;
						trackerData.ones_season_peak = playlist?.stats?.peakRating?.value ?? 0;
					}

					trackerData.psyonix_season = playlist.attributes.season;
					trackerData.platform = platform;
					trackerData.user_id = user_id;
				}

				fetch('https://devleague.rscstream.com/save_mmr', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(trackerData)
				}).then(response => {
					if ( response.ok ) {
						return response.json();
					} else {
						console.error("Post failed!", response);
					}
				}).then(data => {
					if ( data.success ) {
						console.log('save successful');
						el.innerText = 'MMR Saved!';

						// if it's our first pull, try to get two seasons
						if ( trackerData.status === 'NEW' || FULL_PULLS ) {
							console.log(`Trying to grab season old data for ${RTN_player_id}`);
							el.innerText = `Fetching Historical Data`;
							if ( FULL_PULLS ) {
								// this will do a deep pull until Season 15 (F2P)
								setTimeout(() => { 
									const old_season = parseInt(season) - 1;
									if ( old_season > 14 ) {
										console.log(`Grabbing season ${season} - 1 = ${parseInt(season) - 1}`);
										fetchMmr(parseInt(season) - 1, RTN_player_id, fallback_tracker_data); 
									} else {
										console.log('Finished!');
									}
								}, Math.floor(Math.random() * 400) + 400);
							} else {
								// this will do a shallow historical just going back
								// 12 months
								setTimeout(() => { fetchHistorical(RTN_player_id, trackerData) }, 500);
							}
							return true;
						}

					} else if ( data.recent )  {
						console.log('save not needed');
						el.innerText = 'Tracker Recently Pulled - Skipping';

					} else if ( data.not_found )  {
						console.log('save not needed');
						el.innerText = 'Not a player';

					} else {
						console.log('Unknown Error');
						el.innerText = 'Error!';
					}
				}).catch(error => {
					el.innerText = 'Error!';
					console.log('Error:', error);
				});
			}).catch(_error => {
				console.log('Error:', _error);
				el.innerText = 'Error!';

				fetch('https://devleague.rscstream.com/bad_tracker', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify({'pulled_by': rsc_name, 'tracker_link': old_link, 'current_page': window.location.href })
				}).then(response => response.json())
				.then(_json => {
					el.innerText = 'Error - logged!';
				});
			});
	} else {
		// we're not on a profile page, but if we got here from the API endpoint
		// that provided us with this URL, log this tracker as "bad"
		if ( currentTracker === tracker_link ) {
			fetch('https://devleague.rscstream.com/bad_tracker', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({'pulled_by': rsc_name, 'tracker_link': window.location.href })
			}).then(response => response.json())
			.then(_json => {
				el.innerText = 'Error - logged!';
			});
		} else {
			el.innerText = 'Not a Profile';
		}
	}
}

function createDomElement(html) {
	const dom = new DOMParser().parseFromString(html, 'text/html');
	return dom.body.firstElementChild;
}

console.log('RSC MMR Checker Loaded!');
